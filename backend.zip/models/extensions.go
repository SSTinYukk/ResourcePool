package models

// 为Category模型添加额外的字段
// 这些字段通过在models.go中的Category结构体中添加字段来实现
// 不需要重新定义Category结构体
